// 1. Triângulo
let LadoX = document.querySelector("#LadoX");
let LadoY = document.querySelector("#LadoY");
let LadoZ = document.querySelector("#LadoZ");
let CalcularTriangulo = document.querySelector("#CalcularTriangulo");
let ResultadoTriangulo = document.querySelector("#ResultadoTriangulo");

function Calcular() {
  let x = Number(LadoX.value.replace(",", "."));
  let y = Number(LadoY.value.replace(",", "."));
  let z = Number(LadoZ.value.replace(",", "."));

  if (x < y + z && y < x + z && z < x + y) {
    if (x === y && y === z) {
      ResultadoTriangulo.innerText = "Triângulo Equilátero";
    } else if (x === y || y === z || x === z) {
      ResultadoTriangulo.innerText = "Triângulo Isósceles";
    } else {
      ResultadoTriangulo.innerText = "Triângulo Escaleno";
    }
  } else {
    ResultadoTriangulo.innerText = "Não é um triângulo";
  }
}

CalcularTriangulo.onclick = function() {
    Calcular()
};

// 2. Calculadora IMC
let Peso = document.querySelector("#Peso");
let Altura = document.querySelector("#Altura");
let CalcularIMC = document.querySelector("#CalcularIMC");
let ResultadoIMC = document.querySelector("#ResultadoIMC");

function Calcular2() {
  let P = Number(Peso.value.replace(",", "."));
  let A = Number(Altura.value.replace(",", "."));

  let Imc = P / (A * A);
  let Categoria = "";

  if (Imc < 18.5) Categoria = "Abaixo do Peso";
  else if (Imc < 24.9) Categoria = "Normal";
  else if (Imc < 29.9) Categoria = "Sobrepeso";
  else if (Imc < 34.9) Categoria = "Obesidade grau 1";
  else if (Imc < 39.9) Categoria = "Obesidade grau 2";
  else Categoria = "Obesidade grau 3";

  ResultadoIMC.innerText = `IMC: ${Imc.toFixed(2)} (${Categoria})`;
}

CalcularIMC.onclick = function() {
    Calcular2()
};

// 3. Calculadora de Impostos
let AnoCarro = document.querySelector("#AnoCarro");
let ValorCarro = document.querySelector("#ValorCarro");
let CalcularImposto = document.querySelector("#CalcularImposto");
let ResultadoImposto = document.querySelector("#ResultadoImposto");

function Calcular3() {
  let Ano = Number(AnoCarro.value);
  let Valor = Number(ValorCarro.value.replace(",", "."));
  let Taxa = 0;

  if (Ano < 1990) {
    Taxa = 0.01;
  } else {
    Taxa = 0.015;
  }

  let Imposto = Valor * Taxa;

  ResultadoImposto.innerHTML = `
    Ano do carro: ${Ano}<br>
    Valor de tabela: R$ ${Valor.toFixed(2)}<br>
    Taxa aplicada: ${(Taxa * 100).toFixed(1)}%<br>
    <strong>Imposto a pagar: R$ ${Imposto.toFixed(2)}</strong>`;
}

CalcularImposto.onclick = function () {
  Calcular3();
};

// 4. Calculadora de Salário
let Salario = document.querySelector("#Salario");
let Cargo = document.querySelector("#Cargo");
let CalcularSalario = document.querySelector("#CalcularSalario");
let ResultadoSalario = document.querySelector("#ResultadoSalario");

function Calcular4() {
  let SalarioAtual = Number(Salario.value.replace(",", "."));
  let cargo = Cargo.value.trim().toLowerCase();
  let Aumento = 0;

  if (cargo === "gerente") {
    Aumento = 0.10;
  } else if (cargo === "engenheiro") {
    Aumento = 0.20;
  } else if (cargo === "técnico" || cargo === "tecnico") {
    Aumento = 0.30;
  } else {
    Aumento = 0.40;
  }

  let NovoSalario = SalarioAtual * (1 + Aumento);
  let Diferenca = NovoSalario - SalarioAtual;

  ResultadoSalario.innerHTML = `
    Salário antigo: R$ ${SalarioAtual.toFixed(2)}<br>
    Novo salário: R$ ${NovoSalario.toFixed(2)}<br>
    Diferença: R$ ${Diferenca.toFixed(2)} (${(Aumento * 100).toFixed(0)}% de aumento)`;
}

CalcularSalario.onclick = function () {
  Calcular4();
};

// 5. Calculadora de Crédito Bancário
let Saldo = document.querySelector("#Saldo");
let CalcularCredito = document.querySelector("#CalcularCredito");
let ResultadoCredito = document.querySelector("#ResultadoCredito");

function Calcular5() {
  let ValorSaldo = Number(Saldo.value.replace(",", "."));
  let Credito = 0;
  let Percentual = 0;

  if (ValorSaldo < 200) {
    Credito = 0;
    Percentual = 0;
  } else if (ValorSaldo <= 400) {
    Percentual = 0.2;
    Credito = ValorSaldo * Percentual;
  } else if (ValorSaldo <= 600) {
    Percentual = 0.3;
    Credito = ValorSaldo * Percentual;
  } else {
    Percentual = 0.4;
    Credito = ValorSaldo * Percentual;
  }

  ResultadoCredito.innerHTML = `
    Saldo médio: R$ ${ValorSaldo.toFixed(2)}<br>
    ${Credito > 0 ? `Crédito concedido: R$ ${Credito.toFixed(2)} (${(Percentual * 100).toFixed(0)}%)` : 
    "Nenhum crédito concedido para saldo abaixo de R$ 200,00."}`;
}

CalcularCredito.onclick = function () {
  Calcular5();
};

// 6. Lanchonete
let CodigoItem = document.querySelector("#CodigoItem");
let QuantidadeItem = document.querySelector("#QuantidadeItem");
let CalcularLanche = document.querySelector("#calcularLanche");
let ResultadoLanche = document.querySelector("#ResultadoLanche");

function Calcular6() {
  let Codigo = CodigoItem.value.trim();
  let Quantidade = Number(QuantidadeItem.value.replace(",", "."));
  let Preco = 0;
  let Nome = "";

  switch (Codigo) {
    case "100":
      Preco = 11.00;
      Nome = "Cachorro Quente";
      break;
    case "101":
      Preco = 8.50;
      Nome = "Bauru";
      break;
    case "102":
      Preco = 8.00;
      Nome = "Misto Quente";
      break;
    case "103":
      Preco = 9.00;
      Nome = "Hambúrguer";
      break;
    case "104":
      Preco = 10.00;
      Nome = "Cheeseburguer";
      break;
    case "105":
      Preco = 4.50;
      Nome = "Refrigerante";
      break;
  }

  let Total = Preco * Quantidade;

  ResultadoLanche.innerHTML = `
    Item: ${Nome} <br>
    Quantidade: ${Quantidade} <br>
    Total a pagar: R$ ${Total.toFixed(2)}`;
}

CalcularLanche.onclick = function () {
  Calcular6();
};

// 7. Sistema de Vendas
let PrecoProduto = document.querySelector("#PrecoProduto");
let Pagamento = document.querySelector("#Pagamento");
let CalcularVenda = document.querySelector("#CalcularVenda");
let ResultadoVenda = document.querySelector("#ResultadoVenda");

function Calcular7() {
  let Preco = Number(PrecoProduto.value.replace(",", "."));
  let Forma = Pagamento.value;

  let ValorFinal = Preco;
  switch (Forma) {
    case "a":
      ValorFinal = Preco * 0.9;
      break;
    case "b":
      ValorFinal = Preco * 0.95;
      break;
    case "c":
      ValorFinal = Preco;
      break;
    case "d":
      ValorFinal = Preco * 1.1;
      break;
  }

  ResultadoVenda.innerText = `Valor a pagar: R$ ${ValorFinal.toFixed(2)}`;
}

CalcularVenda.onclick = function() {
    Calcular7()
};

// 8. Pagamento de Professores
let Nivel = document.querySelector("#Nivel");
let Aulas = document.querySelector("#Aulas");
let CalcularProfessor = document.querySelector("#CalcularProfessor");
let ResultadoProfessor = document.querySelector("#ResultadoProfessor");

function Calcular8() {
  let N = Number(Nivel.value);
  let Horas = Number(Aulas.value.replace(":", "."));

  let ValorHora = 0;

  switch (N) {
    case 1: ValorHora = 12.00; break;
    case 2: ValorHora = 17.00; break;
    case 3: ValorHora = 25.00; break;
  }

  let Pagamento = ValorHora * Horas * 4.5;
  ResultadoProfessor.innerText = `Pagamento semanal: R$ ${Pagamento.toFixed(2)}`;
}

CalcularProfessor.onclick = function() {
    Calcular8()
};